<?php

return [
    'home' => 'Casa',
    'account' => [
        'header' => 'Configuração De Conta',
        'my_account' => 'Minha Conta',
        'security_controls' => 'Controle de Segurança',
        'api_access' => 'Conta de Api',
        'my_servers' => 'Meus Servidores',
    ],
    'server' => [
        'header' => 'Servidor',
        'console' => 'Console',
        'console-pop' => 'Fullscreen Console',
        'file_management' => 'Gerenciador Arquivos',
        'file_browser' => 'Navegador De Arquivos',
        'create_file' => 'Criar Arquivo',
        'upload_files' => 'Upar Arquivo',
        'subusers' => 'Sub Usuário',
        'schedules' => 'Horarios',
        'configuration' => 'Configuração',
        'port_allocations' => 'Trocar Porta',
        'sftp_settings' => 'Configuração SFTP',
        'startup_parameters' => 'Inicialização',
        'databases' => 'Databases',
        'edit_file' => 'Editar Arquivos',
        'admin_header' => 'ADMINISTRAÇÃO',
        'admin' => 'Configuração Admin',
	'server_name' => 'Nome Do Servidor',   
],
];
